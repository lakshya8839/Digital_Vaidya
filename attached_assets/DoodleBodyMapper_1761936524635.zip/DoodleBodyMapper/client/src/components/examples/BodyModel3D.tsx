import { BodyModel3D } from '../BodyModel3D';

export default function BodyModel3DExample() {
  return (
    <div className="w-full h-screen">
      <BodyModel3D />
    </div>
  );
}
